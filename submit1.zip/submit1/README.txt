To reviewer: Please note this is a partial submission, I'm just looking for feedback on what I've done so far in my report. That's why code isn't provided.

Thanks a lot!